const express = require('express')
const app = express()
const insarray = require('./InitialData')
const bodyParser = require("body-parser");
const port = 8080
app.use(express.urlencoded());

// Parse JSON bodies (as sent by API clients)
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
// your code goes here

let newId = insarray.length;
app.get('/api/student',(req,res)=>{
    try{
        res.json({
            status:"Success",
            insarray
        })
    }catch(e){
        res.status(400).json({
            status:"Failure",
            message:e.message
        })
    }
})

app.get('/api/student/:id',(req,res)=>{
    try{
        const index = insarray.findIndex((obj => obj.id ==req.params.id))
       
        if(index== -1){
            return res.status(400).json({
                status:"Failure",
                message: "Invalied index value"
            })
        }
        // console.log(index);
        res.json({
            status:"Success",
            insarray : insarray[index]
        })
    }catch(e){
        res.status(400).json({
            status:"Failure",
            message:e.message
        })
    }
})

app.post('/api/student',(req,res)=>{
    // pushing the re
    insarray.push(req.body)
   
    try{
        if(!req.body.name || !req.body.currentClass || !req.body.division){
            return res.status(400).json({
                status:"Failed",
                message: "No sufficent data"
            })
        }
        insarray.push({
            id:newId++,
            name:req.body.name,
            currentClass: req.body.currentClass,
            division:req.body.division
        })
        newId++;

        res.json({
            status:"Success",
            insarray
        })
    }catch(e){
        res.status(400).json({
            status:"Failure",
            message:e.message
        })
    }
})
app.put('/api/student/:id',(req,res)=>{
    try{
        const index = insarray.findIndex((obj => obj.id ==req.params.id))
       
        if(index== -1){
            return res.status(400).json({
                status:"Failure",
                message: "cant update"
            })
        }
       if(req.body.name)
        insarray[index].name = req.body.name
        if(req.body.currentClass)
        insarray[index].currentClass = req.body.currentClass
        if(req.body.division)
        insarray[index].division = req.body.division
        res.json({
            status:"Success",
            insarray : insarray[index]
        })
    }catch(e){
        res.status(400).json({
            status:"Failure",
            message:e.message
        })
    }
})
app.delete('/api/student/:id',(req,res)=>{
    try{
        const index = insarray.findIndex((obj => obj.id ==req.params.id))
       
        if(index== -1){
            return res.status(400).json({
                status:"deleted",
                message: "no such data found"
            })
        }
        
        //deleting
        insarray.splice(index,1)
        res.json({
            status:"Success",
            message:"data deleted"
        })
    }catch(e){
        res.status(400).json({
            status:"Failure",
            message:e.message
        })
    }
})



app.listen(port, () => console.log(`App listening on port ${port}!`))

module.exports = app;   